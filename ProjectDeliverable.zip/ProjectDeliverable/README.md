# ISA616Project
To ensure the markdown document knit successully, please make sure the following has applied: 

## BusinessValueProposition.PNG
Please make sure the "BusinessValueProposition.PNG" file is in the same folder as the markdown document, or source it as needed

## refs.bib - reference
Please make sure the "refs.bib" file is in the same folder as the markdown document, or source it as needed

## Functions.R
Please make sure "Functions.R" file is in the same folder as the markdown document, or source it as needed

## Datasets
Please make sure "winequality-red.csv" and "winequality-white.csv" are both stored in the same folder as the markdown document, or source them as needed

## Debugging
If you have an "html_dependancy" error, please locate to the folder and delete "ProjectMarkdown_cache" folders before you kint the RMD file
